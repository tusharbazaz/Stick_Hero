package com.example.mygame;

public class MyGameException extends Exception {
    public MyGameException(String message) {
        super(message);
    }

}
